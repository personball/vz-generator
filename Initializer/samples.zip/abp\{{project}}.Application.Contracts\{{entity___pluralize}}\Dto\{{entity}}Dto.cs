namespace {{project}}.{{entity|pluralize}}.Dto

public record {{entity}}Dto(

);
