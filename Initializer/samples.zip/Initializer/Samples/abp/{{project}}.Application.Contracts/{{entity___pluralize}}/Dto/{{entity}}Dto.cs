namespace {{project}}.{{entity|string.pluralize}}.Dto

public record {{entity}}Dto(

);
