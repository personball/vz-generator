namespace {{project}}.{{entity|string.pluralize}}.Dto

public record Create{{entity}}Dto(
// TODO: add properties
);
