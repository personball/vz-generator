namespace {{project}}.{{entity|pluralize}}.Dto;

public record Update{{entity}}Dto(
// TODO: add properties
);
