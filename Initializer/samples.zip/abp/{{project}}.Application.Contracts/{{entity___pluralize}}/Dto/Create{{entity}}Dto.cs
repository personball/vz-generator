namespace {{project}}.{{entity|pluralize}}.Dto;

public record Create{{entity}}Dto(
// TODO: add properties
);
